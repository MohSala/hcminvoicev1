<!DOCTYPE html>
<html>
<head>
	<title>Snapnet | Invoice</title>
</head>
<body>
	<div style="width: 1000px">	
<table  style="width: 100%">
	<thead> 
	<th style ="width: 60%;font-size: 48px;text-align: left"><img src="dist/img/logo.png" class="img" alt="User Image"></th>

	<th style="width: 40%;font-size: 16px;color: black;text-align: center; font-family:sans-serif; ">1B Abayomi Shonuga Crescent <br>Off Dele Adedeji Street, <br> Lekki Phase 1, <br> Lagos Nigeria. <br> </th>
	</thead>
	<tbody></tbody>
</table>
<hr style="color: black">
<table style="width: 100%">
	<thead> 
	<th style ="width: 60%;font-size: 16px;text-align: left;padding-left: 30px">Invoice No: </th>
	<th style="width: 40%;font-size: 20px;color: red;text-align: center; font-family:sans-serif; ">Unpaid</th>
	</thead>
</table>
<hr>
<table style="width: 100%">
	<thead> 
	<th style ="width: 60%;font-size: 20px;text-align: left;">Details of Receiver (Billed To)</th>
	</thead>
</table>
<hr>
<table style="width: 100%">
	<thead> 
	<th style ="width: 60%;font-size: 16px;text-align: left;padding-left: 30px;">Company Name:	 <br>Address:		 <br>Country:	Nigeria <br>GSTIN ID: <br>VAT No:</th>
	</thead>
</table>
<hr>
<table style="width: 100%" style="border-collapse: collapse;">
	<thead>
		<th  style="font-family: sans-serif;width: 10%">S/N</th>
	<th  style="font-family: sans-serif;width: 30%">Description</th>
	<th style="font-family: sans-serif;width: 10%">Qty</th>
	<th style="font-family: sans-serif;width: 20%">Unit Cost(=N=)</th>
	<th  style="font-family: sans-serif;width: 10%">Discount(%)</th>
	<th  style="font-family: sans-serif;width: 20%">Total(=N=)</th>
	</thead>
</table>
<hr>
<table style="width: 100%">
	<thead></thead>
	<tbody>
	<tr style="text-align: center;">
			<td style="width:10%"></td>
			<td style="width:30%"></td>
			<td style="width:10%"></td>
			<td style="width:20%"></td>
			<td style="width:10%">%</td>
			<td style="width:20%"></td>
	</tr>
	</tbody>
</table>
<br>	
<br>	
<hr>	
<table style="width: 100%">	
		<thead></thead>
		<tbody>	
			<tr>	
			<td style="width:10%"></td><td style="width:30%"></td><td style="width:10%"></td>
				
			<td style="width:20%" ></td>
			<td style="font-size: 20px;width: 10%"><b>Subtotal:</b></td>
			<td style="text-align: center;width:20%;font-family:'Open Sans', sans-serif;">
				<b>N</b>
			</td>
			</tr>
			<tr>	
			<td style="width: 10%"></td>
			<td  style="width:30% "></td><td style="width:10% "></td>
				
			<td style="width: 20%" ></td>
			<td  style="font-size: 20px;width: 20%"><b>Service.Charge:</b></td>
			<td  style="text-align: center;width:20%;font-family:'Open Sans', sans-serif;">
				<b>N</b>
			</td>
			</tr>
			<tr>	
			<td style="width: 10%"></td>
			<td  style="width: 30%"></td>
			<td  style="width: 10%"></td>
				
			<td style="width: 20%" ></td>
			<td  style="font-size: 20px;width: 10%"><b>Total:</b></td>
			<td  style="text-align: center;width:20%;font-family:'Open Sans', sans-serif;">
				<b>N</b>
			</td>
			</tr>
			<tr>	
			<td  style="width: 10%"></td>
			<td style="width: 30%"></td>
			<td  style="width: 10%"></td>
				
			<td style="width: 20%" ></td>
			<td  style="font-size: 20px;width: 10%"><b>VAT 5%:</b></td>
			<td style="text-align: center;width:20%;font-family:'Open Sans', sans-serif;">
				<b>N</b>
			</td>
			</tr>
			<tr>	
			<td  style="width:10%"></td>
			<td  style="width:30%"></td>
			<td  style="width:10%"></td>
				
			<td style="width: 20%" ></td>
			<td  style="font-size: 20px;width: 20%"><b>TOTAL:</b></td>
			<td  style="text-align: center;width:20%;font-size: 20px;font-family:'Open Sans', sans-serif;text-decoration: overline;">
				<b><u></u></b>
			</td>
			</tr>
		</tbody>
		
</table>
<br><br><br>
<hr>	
<table>	
		<thead></thead>
	<tbody>
		<tr style="text-align: center;">
			<td  style="width: 10%"></td>
			<td style="width: 30%">Make All cheques Payable <br><br>Account Name:Snapnet Limited <br>Bank:Diamond Bank Plc. <br>Account #: 0073821499 <br>TIN:-02298087-0001 <br>For enquiries contact sales@snapnet.com.ng</td>
			<td  style="width: 10%"></td>
			<td style="width: 10%"></td>
			<td  style="width: 20%"></td>
			<td style="width: 20%">Payment Terms:80% <br>Upfront,20% on Delivery</td>
			
		</tr>
		
	</tbody>
</table>
</div>
</body>
</html>