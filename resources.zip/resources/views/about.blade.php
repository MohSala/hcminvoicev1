@extends('layouts.app')
@section('content')
Home page
@endsection